# Sample games

### These are examples of how your game structure could look like

+ `hangman.py`: A simple game of hangman, this is also the default game loaded when no game is defined on creating a NetHangServer() object.
