"""Import wrapper calls to library."""

# Class for server handling
from NetHang.server import HangmanServer

# Wrapper functions
from NetHang.run import cli_run, cli_stop
