# NetHang
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![CodeFactor](https://www.codefactor.io/repository/github/magnetrwn/NetHang/badge)](https://www.codefactor.io/repository/github/magnetrwn/NetHang)

Compact, client-server Python application to play hangman using netcat (nc) or any other TCP client.
Get the wheel (.whl) from `dist` or run `make install` yourself. When installed, just run `NetHang` or `nethang` from shell to start the server.

**Currently work in progress...**

... add asciinema demo here ...