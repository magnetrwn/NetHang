"""Sets up the NetHang package"""


from setuptools import setup

setup()
