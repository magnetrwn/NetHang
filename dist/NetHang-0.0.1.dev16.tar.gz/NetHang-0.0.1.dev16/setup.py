"""Sets up the NetHang package wheel"""


from setuptools import setup

setup()
