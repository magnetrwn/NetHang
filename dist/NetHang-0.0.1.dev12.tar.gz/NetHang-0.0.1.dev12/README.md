# NetHang
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![CodeFactor](https://www.codefactor.io/repository/github/magnetrwn/NetHang/badge)](https://www.codefactor.io/repository/github/magnetrwn/NetHang)

Compact, client-server Python application to play hangman using netcat (nc) or any other TCP client.
Get the wheel (.whl) from `dist` or run `make install` yourself.
When installed, just run `NetHang` or `nethang` from shell to start the server.
Make sure to check `config/settings.yml`, which will be bundled with NetHang in Python's site-packages, for configuring the server when run from shell.
The package can also easily be used as a module, under python3:
```
import NetHang
server = NetHang.cli_run()
# do whatever
NetHang.cli_stop(server)
```
as well as
```
from NetHang.server import HangmanServer

```
At the moment logging is not yet integrated, in favor of basic print statements, will switch soon.

**Currently work in progress...**

... add asciinema demo here ...